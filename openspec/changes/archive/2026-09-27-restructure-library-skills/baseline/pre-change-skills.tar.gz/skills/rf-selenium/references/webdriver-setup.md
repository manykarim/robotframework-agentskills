# WebDriver Setup Guide

## Overview

SeleniumLibrary drives real browsers through WebDriver. Install the library into the project environment (`uv add robotframework-seleniumlibrary`, see **rf-setup**); drivers need no separate setup.

## Drivers: Selenium Manager

Selenium ≥ 4.6 bundles **Selenium Manager**, which resolves the driver for you:

- **A browser must be installed** (Chrome, Firefox, Edge). Selenium Manager can also download Chrome/Firefox if none is found, but installing the browser explicitly is more predictable in CI.
- The matching driver (chromedriver, geckodriver, msedgedriver) is fetched on the first `Open Browser` and cached in `~/.cache/selenium`. Set `SE_CACHE_PATH` to move the cache (for example into a CI cache directory).
- No `PATH` setup, no driver downloads, no helper libraries.
- **Offline or locked-down machines** (no access to the driver download endpoints): see rf-setup `references/libraries.md` for the pre-provisioned driver setup.

```robotframework
*** Settings ***
Library    SeleniumLibrary

*** Test Cases ***
Open With Selenium Manager
    Open Browser    https://example.com    chrome    # driver resolved automatically
    [Teardown]    Close Browser
```

## Browser Options

### Chrome Options

```robotframework
*** Keywords ***
Open Chrome With Options
    [Arguments]    ${url}
    ${options}=    Evaluate    sys.modules['selenium.webdriver'].ChromeOptions()    sys
    Call Method    ${options}    add_argument    --headless
    Call Method    ${options}    add_argument    --no-sandbox
    Call Method    ${options}    add_argument    --disable-dev-shm-usage
    Call Method    ${options}    add_argument    --window-size=1920,1080
    Create WebDriver    Chrome    options=${options}
    Go To    ${url}
```

### Common Chrome Arguments

```robotframework
# Headless mode
options=add_argument("--headless")

# Disable sandbox (for CI/Docker)
options=add_argument("--no-sandbox")

# Disable shared memory (for Docker)
options=add_argument("--disable-dev-shm-usage")

# Window size
options=add_argument("--window-size=1920,1080")

# Start maximized
options=add_argument("--start-maximized")

# Disable GPU (for headless)
options=add_argument("--disable-gpu")

# Ignore certificate errors
options=add_argument("--ignore-certificate-errors")

# Disable extensions
options=add_argument("--disable-extensions")

# User agent
options=add_argument("--user-agent=Custom User Agent")

# Download directory
options=add_experimental_option("prefs", {"download.default_directory": "/path/to/downloads"})
```

### Firefox Options

```robotframework
*** Keywords ***
Open Firefox With Options
    [Arguments]    ${url}
    ${options}=    Evaluate    sys.modules['selenium.webdriver'].FirefoxOptions()    sys
    Call Method    ${options}    add_argument    -headless
    Create WebDriver    Firefox    options=${options}
    Go To    ${url}
```

### Common Firefox Arguments

```robotframework
# Headless mode
options=add_argument("-headless")

# Window size (in headless)
options=add_argument("--width=1920")
options=add_argument("--height=1080")
```

### Edge Options

```robotframework
*** Keywords ***
Open Edge With Options
    [Arguments]    ${url}
    ${options}=    Evaluate    sys.modules['selenium.webdriver'].EdgeOptions()    sys
    Call Method    ${options}    add_argument    --headless
    Create WebDriver    Edge    options=${options}
    Go To    ${url}
```

## Headless Browsers

### Built-in Headless Aliases

```robotframework
# Chrome headless
Open Browser    ${URL}    headless_chrome
Open Browser    ${URL}    headlesschrome
Open Browser    ${URL}    gc    # Also headless

# Firefox headless
Open Browser    ${URL}    headless_firefox
Open Browser    ${URL}    headlessfirefox
Open Browser    ${URL}    ff    # Also headless

# Edge headless
Open Browser    ${URL}    headless_edge
```

### Custom Headless Setup

```robotframework
*** Keywords ***
Open Headless Chrome
    [Arguments]    ${url}
    Open Browser    ${url}    chrome
    ...    options=add_argument("--headless");add_argument("--window-size=1920,1080")
```

## Selenium Grid / Remote WebDriver

### Connect to Selenium Grid

```robotframework
*** Variables ***
${GRID_URL}    http://localhost:4444/wd/hub

*** Keywords ***
Open Browser On Grid
    [Arguments]    ${url}    ${browser}=chrome
    Open Browser    ${url}    ${browser}    remote_url=${GRID_URL}
```

### With Desired Capabilities

```robotframework
*** Keywords ***
Open Chrome On Grid With Capabilities
    [Arguments]    ${url}
    ${caps}=    Create Dictionary
    ...    browserName=chrome
    ...    platformName=linux
    ...    browserVersion=latest
    Open Browser    ${url}    chrome
    ...    remote_url=${GRID_URL}
    ...    desired_capabilities=${caps}
```

### Selenium Grid 4 (W3C Capabilities)

```robotframework
*** Keywords ***
Open Browser On Grid 4
    [Arguments]    ${url}
    ${options}=    Evaluate    sys.modules['selenium.webdriver'].ChromeOptions()    sys
    Call Method    ${options}    set_capability    platformName    linux
    Create WebDriver    Remote
    ...    command_executor=${GRID_URL}
    ...    options=${options}
    Go To    ${url}
```

## Docker Setup

### docker-compose.yml for Selenium Grid

```yaml
version: '3'
services:
  selenium-hub:
    image: selenium/hub:latest
    ports:
      - "4444:4444"

  chrome:
    image: selenium/node-chrome:latest
    depends_on:
      - selenium-hub
    environment:
      - SE_EVENT_BUS_HOST=selenium-hub
      - SE_EVENT_BUS_PUBLISH_PORT=4442
      - SE_EVENT_BUS_SUBSCRIBE_PORT=4443

  firefox:
    image: selenium/node-firefox:latest
    depends_on:
      - selenium-hub
    environment:
      - SE_EVENT_BUS_HOST=selenium-hub
      - SE_EVENT_BUS_PUBLISH_PORT=4442
      - SE_EVENT_BUS_SUBSCRIBE_PORT=4443
```

### Standalone Containers

```bash
# Chrome standalone
docker run -d -p 4444:4444 -p 7900:7900 --shm-size="2g" selenium/standalone-chrome:latest

# Firefox standalone
docker run -d -p 4444:4444 -p 7900:7900 --shm-size="2g" selenium/standalone-firefox:latest
```

### Connect from Robot Framework

```robotframework
*** Variables ***
${REMOTE_URL}    http://localhost:4444

*** Keywords ***
Open Browser In Docker
    [Arguments]    ${url}
    Open Browser    ${url}    chrome    remote_url=${REMOTE_URL}
```

## CI/CD Configuration

Install dependencies from the project's lock file (see **rf-setup** `references/ci.md` for pip/Poetry variants). Selenium Manager resolves the driver, so no separate driver installation step is needed.

### GitHub Actions

```yaml
jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - name: Install uv
        uses: astral-sh/setup-uv@v6

      - name: Install Chrome
        uses: browser-actions/setup-chrome@v1

      - name: Install dependencies
        run: uv sync --locked

      - name: Run tests
        run: uv run robot --variable BROWSER:headless_chrome tests/
```

### GitLab CI (Selenium Grid service)

```yaml
test:
  image: ghcr.io/astral-sh/uv:python3.12-bookworm
  services:
    - selenium/standalone-chrome:latest
  variables:
    SELENIUM_REMOTE_URL: http://selenium__standalone-chrome:4444
  script:
    - uv sync --locked
    - uv run robot --variable REMOTE_URL:$SELENIUM_REMOTE_URL tests/
```

### Jenkins

```groovy
pipeline {
    agent any

    stages {
        stage('Test') {
            steps {
                sh '''
                    uv sync --locked
                    uv run robot --variable BROWSER:headless_chrome tests/
                '''
            }
        }
    }

    post {
        always {
            robot outputPath: '.', passThreshold: 95.0
        }
    }
}
```

## Browser Profiles

### Chrome Profile

```robotframework
*** Keywords ***
Open Chrome With Profile
    [Arguments]    ${url}
    ${options}=    Evaluate    sys.modules['selenium.webdriver'].ChromeOptions()    sys
    Call Method    ${options}    add_argument    user-data-dir=/path/to/profile
    Call Method    ${options}    add_argument    profile-directory=Default
    Create WebDriver    Chrome    options=${options}
    Go To    ${url}
```

### Firefox Profile

```robotframework
*** Keywords ***
Open Firefox With Profile
    [Arguments]    ${url}
    Open Browser    ${url}    firefox
    ...    ff_profile_dir=/path/to/firefox/profile
```

## Download Configuration

### Chrome Download Directory

```robotframework
*** Keywords ***
Configure Chrome Downloads
    [Arguments]    ${download_dir}
    ${prefs}=    Create Dictionary
    ...    download.default_directory=${download_dir}
    ...    download.prompt_for_download=${False}
    ...    download.directory_upgrade=${True}
    ${options}=    Evaluate    sys.modules['selenium.webdriver'].ChromeOptions()    sys
    Call Method    ${options}    add_experimental_option    prefs    ${prefs}
    Create WebDriver    Chrome    options=${options}
```

### Firefox Download Directory

```robotframework
*** Keywords ***
Configure Firefox Downloads
    [Arguments]    ${download_dir}
    ${profile}=    Evaluate    sys.modules['selenium.webdriver'].FirefoxProfile()    sys
    Call Method    ${profile}    set_preference    browser.download.folderList    2
    Call Method    ${profile}    set_preference    browser.download.dir    ${download_dir}
    Call Method    ${profile}    set_preference    browser.helperApps.neverAsk.saveToDisk
    ...    application/pdf,application/octet-stream
    Create WebDriver    Firefox    firefox_profile=${profile}
```

## Troubleshooting WebDriver Issues

### Common Issues

| Issue | Solution |
|-------|----------|
| Driver/browser version mismatch | Upgrade selenium in the project env (`uv lock --upgrade-package selenium && uv sync`) and clear the Selenium Manager cache (`~/.cache/selenium`) |
| Driver download fails (offline/proxy) | Selenium Manager cannot reach its endpoints; see rf-setup for offline driver setup |
| Session not created | Check browser/driver version compatibility |
| DevToolsActivePort | Add `--no-sandbox` and `--disable-dev-shm-usage` |

### Debug Driver Issues

```robotframework
*** Keywords ***
Debug WebDriver
    # SeleniumLibrary has no capabilities keyword; ask the browser instead
    ${user_agent}=    Execute Javascript    return navigator.userAgent
    Log    User agent: ${user_agent}
    ${session}=    Get Session Id
    Log    Session ID: ${session}
```
