# Gestures and Touch Actions in AppiumLibrary

## Basic Scroll Keywords

### Scroll Down/Up

```robotframework
# Simple scroll
Scroll Down
Scroll Up

# Scroll within specific element
Scroll Down    xpath=//android.widget.ScrollView
Scroll Up      accessibility_id=scrollableList
```

## Swipe Gesture

### Swipe Syntax

```robotframework
# All coordinates are keyword-only (named) arguments; duration is a time
# string such as 500ms or 1s
Swipe    start_x=x1    start_y=y1    end_x=x2    end_y=y2    duration=500ms
```

### Common Swipe Patterns

```robotframework
# Swipe UP (scroll DOWN to see more content)
# Finger moves from bottom to top
Swipe    start_x=500    start_y=1500    end_x=500    end_y=500    duration=1000ms

# Swipe DOWN (scroll UP to see previous content)
# Finger moves from top to bottom
Swipe    start_x=500    start_y=500    end_x=500    end_y=1500    duration=1000ms

# Swipe LEFT (go to next page/item)
# Finger moves from right to left
Swipe    start_x=900    start_y=800    end_x=100    end_y=800    duration=500ms

# Swipe RIGHT (go to previous page/item)
# Finger moves from left to right
Swipe    start_x=100    start_y=800    end_x=900    end_y=800    duration=500ms
```

### Dynamic Swipe Based on Screen Size

```robotframework
*** Keywords ***
Swipe Up Dynamic
    [Arguments]    ${percent}=0.5
    ${width}=     Get Window Width
    ${height}=    Get Window Height
    ${start_x}=    Evaluate    ${width} // 2
    ${start_y}=    Evaluate    int(${height} * 0.8)
    ${end_y}=      Evaluate    int(${height} * 0.2)
    Swipe    start_x=${start_x}    start_y=${start_y}    end_x=${start_x}    end_y=${end_y}    duration=500ms

Swipe Down Dynamic
    ${width}=     Get Window Width
    ${height}=    Get Window Height
    ${start_x}=    Evaluate    ${width} // 2
    ${start_y}=    Evaluate    int(${height} * 0.2)
    ${end_y}=      Evaluate    int(${height} * 0.8)
    Swipe    start_x=${start_x}    start_y=${start_y}    end_x=${start_x}    end_y=${end_y}    duration=500ms

Swipe Left Dynamic
    ${width}=     Get Window Width
    ${height}=    Get Window Height
    ${start_x}=    Evaluate    int(${width} * 0.8)
    ${end_x}=      Evaluate    int(${width} * 0.2)
    ${y}=          Evaluate    ${height} // 2
    Swipe    start_x=${start_x}    start_y=${y}    end_x=${end_x}    end_y=${y}    duration=300ms

Swipe Right Dynamic
    ${width}=     Get Window Width
    ${height}=    Get Window Height
    ${start_x}=    Evaluate    int(${width} * 0.2)
    ${end_x}=      Evaluate    int(${width} * 0.8)
    ${y}=          Evaluate    ${height} // 2
    Swipe    start_x=${start_x}    start_y=${y}    end_x=${end_x}    end_y=${y}    duration=300ms
```

## Scroll Until Element Found

### Android - Using UIAutomator2 (BEST)

```robotframework
# Automatically scrolls to find element!
Click Element    android=new UiScrollable(new UiSelector().scrollable(true)).scrollIntoView(new UiSelector().text("Settings"))

# Horizontal scroll
Click Element    android=new UiScrollable(new UiSelector().scrollable(true).horizontal(true)).scrollIntoView(new UiSelector().text("Tab 5"))

# Scroll in specific container
Click Element    android=new UiScrollable(new UiSelector().resourceId("com.example:id/my_list")).scrollIntoView(new UiSelector().text("Item 50"))

# Scroll to beginning
Click Element    android=new UiScrollable(new UiSelector().scrollable(true)).scrollToBeginning(10)

# Scroll to end
Click Element    android=new UiScrollable(new UiSelector().scrollable(true)).scrollToEnd(10)
```

### Custom Scroll Until Found (Both Platforms)

```robotframework
*** Keywords ***
Scroll Down Until Element Visible
    [Arguments]    ${locator}    ${max_scrolls}=10
    FOR    ${i}    IN RANGE    ${max_scrolls}
        ${visible}=    Run Keyword And Return Status
        ...    Expect Element    ${locator}    visible    timeout=1s
        IF    ${visible}    RETURN
        Swipe    start_x=500    start_y=1500    end_x=500    end_y=700    duration=500ms
    END
    Fail    Element ${locator} not found after ${max_scrolls} scrolls

Scroll Up Until Element Visible
    [Arguments]    ${locator}    ${max_scrolls}=10
    FOR    ${i}    IN RANGE    ${max_scrolls}
        ${visible}=    Run Keyword And Return Status
        ...    Expect Element    ${locator}    visible    timeout=1s
        IF    ${visible}    RETURN
        Swipe    start_x=500    start_y=700    end_x=500    end_y=1500    duration=500ms
    END
    Fail    Element ${locator} not found after ${max_scrolls} scrolls
```

### iOS Scroll Pattern

```robotframework
*** Keywords ***
iOS Scroll To Element
    [Arguments]    ${locator}    ${max_scrolls}=15
    FOR    ${i}    IN RANGE    ${max_scrolls}
        ${visible}=    Run Keyword And Return Status
        ...    Expect Element    ${locator}    visible    timeout=1s
        IF    ${visible}    RETURN
        Swipe    start_x=200    start_y=600    end_x=200    end_y=200    duration=300ms
    END
    Fail    Element ${locator} not found after scrolling
```

## Collect All Elements by Scrolling

### Get All Items in Scrollable List

```robotframework
*** Keywords ***
Get All List Items By Scrolling
    [Arguments]    ${item_locator}    ${max_scrolls}=20
    @{all_items}=    Create List
    ${previous_count}=    Set Variable    0
    FOR    ${i}    IN RANGE    ${max_scrolls}
        @{visible_items}=    Get WebElements    ${item_locator}
        FOR    ${item}    IN    @{visible_items}
            ${text}=    Get Text    ${item}
            ${exists}=    Evaluate    '${text}' in ${all_items}
            IF    not ${exists}
                Append To List    ${all_items}    ${text}
            END
        END
        ${current_count}=    Get Length    ${all_items}
        IF    ${current_count} == ${previous_count}
            BREAK    # No new items found - reached end
        END
        ${previous_count}=    Set Variable    ${current_count}
        Swipe    start_x=500    start_y=1500    end_x=500    end_y=700    duration=500ms
    END
    RETURN    ${all_items}
```

### Usage

```robotframework
*** Test Cases ***
Get All Products
    @{products}=    Get All List Items By Scrolling    class=android.widget.TextView
    Log Many    @{products}
    ${count}=    Get Length    ${products}
    Should Be True    ${count} > 10
```

## Long Press

### Basic Long Press

`Long Press` was removed in AppiumLibrary 3.2.0. `Tap` with a `duration`
holds the touch:

```robotframework
# Long press on element
Tap    locator    duration=1s
Tap    locator    duration=2s    # 2 seconds

# Long press with specific duration
Tap    id=com.example:id/item    duration=3s
Tap    accessibility_id=delete_button    duration=1.5s
```

### Long Press for Context Menu

```robotframework
*** Keywords ***
Open Context Menu
    [Arguments]    ${element_locator}
    Tap    ${element_locator}    duration=1.5s
    Wait Until Page Contains Element    id=context_menu    timeout=5s

*** Test Cases ***
Delete Item Via Context Menu
    Open Context Menu    accessibility_id=list_item_1
    Click Element    android=new UiSelector().text("Delete")
    Page Should Not Contain Element    accessibility_id=list_item_1
```

## Tap by Coordinates

### Click at Specific Position

`Click A Point` was removed in AppiumLibrary 3.0.0. `Tap With Positions`
takes a duration and up to five `(x, y)` tuples (one per finger):

```robotframework
# Tap at x=500, y=800
Tap With Positions    100ms    ${{ (500, 800) }}

# Double tap at coordinates
Tap With Positions    100ms    ${{ (500, 800) }}
Tap With Positions    100ms    ${{ (500, 800) }}

# Or tap a list of coordinates with Tap
Tap    ${{ [500, 800] }}    count=2
```

### Tap Relative to Element

```robotframework
*** Keywords ***
Tap Below Element
    [Arguments]    ${locator}    ${offset_y}=50
    ${location}=    Get Element Location    ${locator}
    ${size}=        Get Element Size       ${locator}
    ${x}=    Evaluate    ${location['x']} + ${size['width']} // 2
    ${y}=    Evaluate    ${location['y']} + ${size['height']} + ${offset_y}
    Tap With Positions    100ms    ${{ (int($x), int($y)) }}
```

## Pinch and Zoom

`Pinch` (removed in 3.0.0) and `Zoom` (removed in 3.2.0) have no keyword
replacement. Call the driver's gesture extensions through `Execute Script`,
which passes the command arguments as named arguments. Sources:
UiAutomator2 driver `docs/android-mobile-gestures.md`
(`mobile: pinchOpenGesture` / `mobile: pinchCloseGesture`: `elementId` or
`left`/`top`/`width`/`height`, required `percent` 0..1, optional `speed`) and
XCUITest driver `docs/reference/execute-methods.md` (`mobile: pinch`:
optional `elementId`, required `scale` and `velocity`).

### Pinch (Zoom Out)

```robotframework
${el}=    Get WebElement    accessibility_id=map_view
# Android (UiAutomator2)
Execute Script    mobile: pinchCloseGesture    elementId=${el.id}    percent=${0.5}
# iOS (XCUITest): scale < 1 zooms out
Execute Script    mobile: pinch    elementId=${el.id}    scale=${0.5}    velocity=${-1.0}
```

### Zoom (Zoom In)

```robotframework
${el}=    Get WebElement    accessibility_id=image_view
# Android (UiAutomator2)
Execute Script    mobile: pinchOpenGesture    elementId=${el.id}    percent=${0.75}
# iOS (XCUITest): scale > 1 zooms in
Execute Script    mobile: pinch    elementId=${el.id}    scale=${2.0}    velocity=${1.0}
```

### Map Interaction Example

```robotframework
*** Test Cases ***
Zoom In On Map
    Wait Until Page Contains Element    accessibility_id=map_view
    Zoom In On Element    accessibility_id=map_view
    Sleep    1s
    Zoom In On Element    accessibility_id=map_view

Zoom Out On Map
    Wait Until Page Contains Element    accessibility_id=map_view
    ${el}=    Get WebElement    accessibility_id=map_view
    Execute Script    mobile: pinchCloseGesture    elementId=${el.id}    percent=${0.5}

*** Keywords ***
Zoom In On Element
    [Arguments]    ${locator}
    ${el}=    Get WebElement    ${locator}
    Execute Script    mobile: pinchOpenGesture    elementId=${el.id}    percent=${0.75}
```

## Pull to Refresh

```robotframework
*** Keywords ***
Pull To Refresh
    ${width}=     Get Window Width
    ${height}=    Get Window Height
    ${x}=       Evaluate    ${width} // 2
    ${start_y}= Evaluate    int(${height} * 0.3)
    ${end_y}=   Evaluate    int(${height} * 0.8)
    Swipe    start_x=${x}    start_y=${start_y}    end_x=${x}    end_y=${end_y}    duration=500ms

*** Test Cases ***
Refresh List
    Pull To Refresh
    Wait Until Page Contains Element    accessibility_id=loading_indicator    timeout=2s
    Wait Until Page Does Not Contain Element    accessibility_id=loading_indicator    timeout=10s
```

## Horizontal Carousel/Swipe

```robotframework
*** Keywords ***
Swipe To Next Carousel Item
    ${width}=     Get Window Width
    ${height}=    Get Window Height
    ${start_x}=    Evaluate    int(${width} * 0.8)
    ${end_x}=      Evaluate    int(${width} * 0.2)
    ${y}=          Evaluate    ${height} // 2
    Swipe    start_x=${start_x}    start_y=${y}    end_x=${end_x}    end_y=${y}    duration=300ms

Swipe To Previous Carousel Item
    ${width}=     Get Window Width
    ${height}=    Get Window Height
    ${start_x}=    Evaluate    int(${width} * 0.2)
    ${end_x}=      Evaluate    int(${width} * 0.8)
    ${y}=          Evaluate    ${height} // 2
    Swipe    start_x=${start_x}    start_y=${y}    end_x=${end_x}    end_y=${y}    duration=300ms

*** Test Cases ***
Navigate Image Carousel
    Wait Until Page Contains Element    accessibility_id=carousel
    Swipe To Next Carousel Item
    Sleep    0.5s
    Swipe To Next Carousel Item
    Sleep    0.5s
    Swipe To Previous Carousel Item
```

## Drag and Drop

### Using Swipe

```robotframework
*** Keywords ***
Drag Element To Position
    [Arguments]    ${source_locator}    ${target_x}    ${target_y}
    ${location}=    Get Element Location    ${source_locator}
    ${size}=        Get Element Size       ${source_locator}
    ${start_x}=     Evaluate    ${location['x']} + ${size['width']} // 2
    ${start_y}=     Evaluate    ${location['y']} + ${size['height']} // 2
    Swipe    start_x=${start_x}    start_y=${start_y}    end_x=${target_x}    end_y=${target_y}    duration=1000ms

Drag Element To Element
    [Arguments]    ${source_locator}    ${target_locator}
    ${src_loc}=     Get Element Location    ${source_locator}
    ${src_size}=    Get Element Size       ${source_locator}
    ${tgt_loc}=     Get Element Location    ${target_locator}
    ${tgt_size}=    Get Element Size       ${target_locator}
    ${start_x}=     Evaluate    ${src_loc['x']} + ${src_size['width']} // 2
    ${start_y}=     Evaluate    ${src_loc['y']} + ${src_size['height']} // 2
    ${end_x}=       Evaluate    ${tgt_loc['x']} + ${tgt_size['width']} // 2
    ${end_y}=       Evaluate    ${tgt_loc['y']} + ${tgt_size['height']} // 2
    Swipe    start_x=${start_x}    start_y=${start_y}    end_x=${end_x}    end_y=${end_y}    duration=1000ms
```

## Practical Examples

### Complete Scrolling Test

```robotframework
*** Test Cases ***
Find And Select Item In Long List
    [Documentation]    Scroll through list to find specific item
    Open Application    ...
    Wait Until Page Contains Element    accessibility_id=product_list

    # Android - use UIAutomator2 auto-scroll
    Click Element    android=new UiScrollable(new UiSelector().scrollable(true)).scrollIntoView(new UiSelector().text("Product XYZ"))

    # Verify selection
    Wait Until Page Contains Element    accessibility_id=product_detail
    Element Text Should Be    accessibility_id=product_title    Product XYZ

*** Test Cases ***
Scroll And Collect All Items
    Open Application    ...
    @{all_items}=    Get All List Items By Scrolling    xpath=//android.widget.TextView[@resource-id='com.example:id/item_name']
    Log    Found ${all_items.__len__()} items
    Should Contain    ${all_items}    Expected Item Name
```

### Gesture-Based Navigation

```robotframework
*** Test Cases ***
Navigate App Using Gestures
    Open Application    ...

    # Swipe through onboarding
    Swipe To Next Carousel Item
    Page Should Contain Text    Step 2
    Swipe To Next Carousel Item
    Page Should Contain Text    Step 3
    Click Element    accessibility_id=get_started

    # Pull to refresh on main screen
    Wait Until Page Contains Element    accessibility_id=feed
    Pull To Refresh

    # Long press to delete item
    Open Context Menu    accessibility_id=feed_item_1
    Click Element    android=new UiSelector().text("Delete")
```
