# AppiumLibrary Keywords Reference

## Session Management

### Open Application

```robotframework
# Open with capabilities
Open Application    remote_url    capability1=value1    capability2=value2    ...

# Android example
Open Application    http://127.0.0.1:4723
...    platformName=Android
...    automationName=UiAutomator2
...    deviceName=emulator-5554
...    app=${CURDIR}/app.apk

# iOS example
Open Application    http://127.0.0.1:4723
...    platformName=iOS
...    automationName=XCUITest
...    deviceName=iPhone 15
...    app=${CURDIR}/app.app

# With alias for multiple sessions
Open Application    http://127.0.0.1:4723    alias=session1    platformName=Android    ...
```

### Close and Quit

```robotframework
Close Application           # Close the current app and end its session
Close All Applications     # Close all open applications
```

### Switch Application

```robotframework
# Open multiple apps
Open Application    ...    alias=app1
Open Application    ...    alias=app2

# Switch between them
Switch Application    app1
Switch Application    app2
```

### App State Management

```robotframework
# No Reset Application / Launch App: control resets with the noReset /
# fullReset capabilities of Open Application
Background Application    seconds=5          # Put app in background
Activate Application      app_id             # Launch or bring to foreground
Terminate Application     app_id             # Kill the app

# Check app state (appId on Android, bundleId on iOS)
${state}=    Execute Script    mobile: queryAppState    appId=app_id
# Returns: NOT_INSTALLED(0), NOT_RUNNING(1), RUNNING_IN_BACKGROUND(3), RUNNING_IN_FOREGROUND(4)
```

### App Installation

```robotframework
Install App           path_to_apk_or_app    app_package
Remove Application    app_id
${installed}=    Execute Script    mobile: isAppInstalled    appId=app_id    # bundleId= on iOS
```

## Element Interaction

### Click Elements

```robotframework
Click Element    locator
Click Text       visible_text

# Long press (Long Press was removed in 3.2.0)
Tap    locator    duration=2s

# Tap at coordinates (Click A Point was removed in 3.0.0)
Tap With Positions    500ms    ${{ (x, y) }}
```

### Input Text

```robotframework
Input Text    locator    text
Input Value   locator    text       # Same as Input Text
Input Password    locator    text   # Masked input

Clear Text    locator
```

### Get Element Properties

```robotframework
${text}=      Get Text              locator
${attr}=      Get Element Attribute    locator    attribute_name
${loc}=       Get Element Location  locator
${size}=      Get Element Size      locator

# Multiple elements
@{elements}=    Get WebElements    locator
${count}=       Get Matching Xpath Count    xpath_locator
```

### Element State

```robotframework
# Assertion keywords return nothing; wrap them to get a boolean
${visible}=     Run Keyword And Return Status    Expect Element    locator    visible
${enabled}=     Run Keyword And Return Status    Expect Element    locator    enabled
${disabled}=    Run Keyword And Return Status    Expect Element    locator    disabled

# Check existence
${exists}=    Run Keyword And Return Status    Page Should Contain Element    locator
```

## Waits

### Wait for Element

```robotframework
Wait Until Element Is Visible       locator    timeout=10s
Wait Until Page Contains Element    locator    timeout=10s
Wait Until Page Does Not Contain Element    locator    timeout=10s
```

### Wait for Text

```robotframework
Wait Until Page Contains    text    timeout=10s
Wait Until Page Does Not Contain    text    timeout=10s
```

### Set Implicit Wait

```robotframework
Set Appium Timeout    10s    # Default element wait timeout
```

## Assertions

### Page Content

```robotframework
Page Should Contain Text       text
Page Should Not Contain Text   text
Page Should Contain Element    locator
Page Should Not Contain Element    locator
```

### Element Content

```robotframework
Element Should Contain Text    locator    expected_text
Element Text Should Be         locator    exact_text
Expect Element                 locator    visible
Expect Element                 locator    not visible
Expect Element                 locator    enabled
Expect Element                 locator    disabled
```

## Scrolling and Gestures

### Scroll

```robotframework
Scroll    locator    # Scroll element into view
Scroll Down
Scroll Up
Scroll Down    locator    # Scroll within element
Scroll Up      locator
```

### Swipe

```robotframework
Swipe    start_x=x1    start_y=y1    end_x=x2    end_y=y2    duration=1s    # keyword-only arguments
Swipe By Percent    start_x_pct    start_y_pct    end_x_pct    end_y_pct    duration=1s
```

### Pinch and Zoom

Pinch and Zoom were removed in AppiumLibrary 3.x. Use the driver gesture
commands (see `gestures-touch.md`):

```robotframework
${el}=    Get WebElement    locator
Execute Script    mobile: pinchCloseGesture    elementId=${el.id}    percent=${0.5}    # Android, zoom out
Execute Script    mobile: pinchOpenGesture     elementId=${el.id}    percent=${0.75}   # Android, zoom in
Execute Script    mobile: pinch    elementId=${el.id}    scale=${2.0}    velocity=${1.0}  # iOS
```

## Screenshots

```robotframework
Capture Page Screenshot                    # Default filename
Capture Page Screenshot    filename.png
Capture Page Screenshot    ${OUTPUT_DIR}/screenshots/screen.png

# No teardown needed for failures: the library's run_on_failure
# (default Capture Page Screenshot) captures a screenshot automatically
```

## Page Source

```robotframework
${source}=    Get Source
Log    ${source}
Log Source                # Log source directly
```

## Context Switching (Hybrid Apps)

```robotframework
# Get current context
${context}=    Get Current Context
Log    Current context: ${context}

# List all contexts
@{contexts}=    Get Contexts
Log Many    @{contexts}
# Typical output: ['NATIVE_APP', 'WEBVIEW_com.example.app']

# Switch to webview
Switch To Context    WEBVIEW_com.example.app

# Switch back to native
Switch To Context    NATIVE_APP
```

## Mobile Browser

```robotframework
Go To Url    url
${url}=    Get Window Url
${title}=    Get Window Title

# Execute JavaScript
${result}=    Execute Script    return document.title
Execute Script    window.scrollTo(0, document.body.scrollHeight)
```

## Android-Specific Keywords

### Key Events

```robotframework
Press Keycode    keycode
Press Keycode    keycode    metastate=modifier

# Common keycodes
Press Keycode    4      # BACK
Press Keycode    3      # HOME
Press Keycode    66     # ENTER
Press Keycode    82     # MENU

# Long press key
Long Press Keycode    keycode
```

### Activity Management

```robotframework
${activity}=    Get Activity
Start Activity    appPackage    appActivity

# Open notifications
Open Notifications
```

### Network and Settings

```robotframework
# Set network connection
Set Network Connection Status    6    # Wifi+Data
# 0=Airplane, 1=Wifi only, 2=Data only, 4=Airplane ON, 6=All connections

${status}=    Get Network Connection Status
```

## iOS-Specific Keywords

### Keyboard

```robotframework
Hide Keyboard
Hide Keyboard    key_name=Done
Hide Keyboard    strategy=pressKey    key=Done
```

### Orientation

```robotframework
Landscape
Portrait
```

### Window Size

```robotframework
${width}=     Get Window Width
${height}=    Get Window Height
```

## Utility Keywords

### Sleep

```robotframework
Sleep    5s
Sleep    500ms
```

### Logging

```robotframework
Log    message
Log    ${variable}
Log Source    # Log page source
```

### Variables

```robotframework
${element}=    Get WebElement    locator
${elements}=   Get WebElements   locator

# Store element for later use
${login_btn}=    Get WebElement    id=login
Click Element    ${login_btn}
```

## Keyword Quick Reference Table

| Category | Keyword | Description |
|----------|---------|-------------|
| Session | Open Application | Start Appium session |
| Session | Close Application | Close app (keep session) |
| Session | Quit Application | End Appium session |
| Session | Reset Application | Clear app data |
| Click | Click Element | Click on element |
| Click | Click Text | Click element by text |
| Click | Long Press | Press and hold |
| Input | Input Text | Enter text |
| Input | Clear Text | Clear text field |
| Get | Get Text | Get element text |
| Get | Get Element Attribute | Get attribute value |
| Get | Get Source | Get page source XML |
| Wait | Wait Until Element Is Visible | Wait for element |
| Wait | Wait Until Page Contains | Wait for text |
| Assert | Page Should Contain Element | Assert element exists |
| Assert | Element Text Should Be | Assert exact text |
| Scroll | Scroll Down | Scroll down |
| Scroll | Swipe | Custom swipe gesture |
| Context | Get Contexts | List available contexts |
| Context | Switch To Context | Change context |
| Screenshot | Capture Page Screenshot | Take screenshot |
| Android | Press Keycode | Send key event |
| Android | Open Notifications | Open notification shade |
